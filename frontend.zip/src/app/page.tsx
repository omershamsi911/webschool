"use client";
import { useEffect, useState } from 'react';
import { fetchStudents } from '../../lib/api';
import StatsCards from './components/dashboard/StatsCards'

export default function Home() {
  const [recentStudents, setRecentStudents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    async function getRecent() {
      try {
        setLoading(true);
        const students = await fetchStudents();
        // Sort by admission_date descending and take 5
        const sorted = students.sort((a, b) => new Date(b.admission_date) - new Date(a.admission_date));
        setRecentStudents(sorted.slice(0, 5));
      } catch (err) {
        setError('Failed to load recent students');
      } finally {
        setLoading(false);
      }
    }
    getRecent();
  }, []);

  return (
    <div className="max-w-7xl mx-auto">
      <h1 className="text-2xl font-bold text-gray-900 mb-6">Dashboard</h1>
      <StatsCards />
      <div className="mt-8">
        <h2 className="text-lg font-medium text-gray-900 mb-4">Recent Students</h2>
        <div className="bg-white shadow overflow-hidden sm:rounded-lg">
          {loading ? (
            <div className="text-center py-8">Loading...</div>
          ) : error ? (
            <div className="text-center text-red-500 py-8">{error}</div>
          ) : (
            <ul className="divide-y divide-gray-200">
              {recentStudents.map((student) => (
                <li key={student.student_id} className="px-4 py-4 sm:px-6">
                  <div className="flex items-center justify-between">
                    <p className="text-sm font-medium text-primary-600 truncate">
                      {student.first_name} {student.last_name}
                    </p>
                    <div className="ml-2 flex-shrink-0 flex">
                      <p className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">
                        {new Date(student.admission_date).toLocaleDateString()}
                      </p>
                    </div>
                  </div>
                  <div className="mt-2 sm:flex sm:justify-between">
                    <div className="sm:flex">
                      <p className="flex items-center text-sm text-gray-500">
                        Class: {student.current_class}
                      </p>
                    </div>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>
    </div>
  );
}