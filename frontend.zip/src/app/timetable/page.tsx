import { fetchClassTimetable } from '../../../lib/api'
import { TimetableEntry } from '../../../lib/types'

export default async function TimetablePage() {
  // For demo, we'll fetch timetable for class 10
  const timetable: TimetableEntry[] = await fetchClassTimetable('10')

  // Group by day of week
  const days = ['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday']
  const timetableByDay = days.map(day => ({
    day,
    entries: timetable.filter(entry => entry.day_of_week === day)
      .sort((a, b) => a.start_time.localeCompare(b.start_time))
  }))

  return (
    <div className="max-w-7xl mx-auto">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold text-gray-900">Class Timetable</h1>
        <div className="flex space-x-4">
          <select className="block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-primary-500 focus:border-primary-500 sm:text-sm rounded-md">
            <option>Class 10</option>
            <option>Class 9</option>
            <option>Class 8</option>
          </select>
          <button className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-primary-600 hover:bg-primary-700">
            Print Timetable
          </button>
        </div>
      </div>

      <div className="bg-white shadow overflow-hidden sm:rounded-lg">
        <div className="grid grid-cols-1 md:grid-cols-7 divide-x divide-y divide-gray-200">
          {timetableByDay.map(({ day, entries }) => (
            <div key={day} className="p-2">
              <h3 className="text-lg font-medium text-center text-gray-900 capitalize mb-2">
                {day}
              </h3>
              {entries.length > 0 ? (
                <ul className="space-y-2">
                  {entries.map((entry) => (
                    <li key={entry.timetable_id} className="p-2 bg-gray-50 rounded">
                      <p className="text-sm font-medium text-gray-900">{entry.subject_name}</p>
                      <p className="text-xs text-gray-500">
                        {entry.start_time} - {entry.end_time}
                      </p>
                      <p className="text-xs text-gray-500">
                        {entry.teacher_first_name} {entry.teacher_last_name}
                      </p>
                      {entry.room_number && (
                        <p className="text-xs text-gray-500">Room: {entry.room_number}</p>
                      )}
                    </li>
                  ))}
                </ul>
              ) : (
                <p className="text-sm text-gray-500 text-center py-4">No classes</p>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}