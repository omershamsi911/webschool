import Link from 'next/link';

const Header = () => {
  return (
    <header className="bg-white shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex justify-between items-center">
        <Link href="/">
          <p className="text-2xl font-bold text-primary-600">Student Portal</p>
        </Link>
        <nav className="flex space-x-8">
          <Link href="/students">
            <p className="text-gray-700 hover:text-primary-600">Students</p>
          </Link>
          <Link href="/fees">
            <p className="text-gray-700 hover:text-primary-600">Fees</p>
          </Link>
          <Link href="/exams">
            <p className="text-gray-700 hover:text-primary-600">Exams</p>
          </Link>
          <Link href="/timetable">
            <p className="text-gray-700 hover:text-primary-600">Timetable</p>
          </Link>
          <Link href="/reports">
            <p className="text-gray-700 hover:text-primary-600">Reports</p>
          </Link>
        </nav>
      </div>
    </header>
  );
};

export default Header;