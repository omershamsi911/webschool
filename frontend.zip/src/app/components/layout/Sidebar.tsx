"use client";
import Link from 'next/link';

const Sidebar = () => {
  return (
    <div className="w-64 bg-white shadow-sm h-screen fixed left-0 top-0 pt-16">
      <div className="p-4">
        <nav className="space-y-1">
          <Link href="/dashboard">
            <p className="flex items-center px-4 py-2 text-gray-700 hover:bg-primary-50 hover:text-primary-600 rounded-lg">
              <span>Dashboard</span>
            </p>
          </Link>
          <Link href="/students">
            <p className="flex items-center px-4 py-2 text-gray-700 hover:bg-primary-50 hover:text-primary-600 rounded-lg">
              <span>Students</span>
            </p>
          </Link>
          <Link href="/fees">
            <p className="flex items-center px-4 py-2 text-gray-700 hover:bg-primary-50 hover:text-primary-600 rounded-lg">
              <span>Fee Management</span>
            </p>
          </Link>
          <Link href="/exams">
            <p className="flex items-center px-4 py-2 text-gray-700 hover:bg-primary-50 hover:text-primary-600 rounded-lg">
              <span>Exams</span>
            </p>
          </Link>
          <Link href="/timetable">
            <p className="flex items-center px-4 py-2 text-gray-700 hover:bg-primary-50 hover:text-primary-600 rounded-lg">
              <span>Timetable</span>
            </p>
          </Link>
          <Link href="/attendance">
            <p className="flex items-center px-4 py-2 text-gray-700 hover:bg-primary-50 hover:text-primary-600 rounded-lg">
              <span>Attendance</span>
            </p>
          </Link>
          <Link href="/reports">
            <p className="flex items-center px-4 py-2 text-gray-700 hover:bg-primary-50 hover:text-primary-600 rounded-lg">
              <span>Reports</span>
            </p>
          </Link>
        </nav>
      </div>
    </div>
  );
};

export default Sidebar;
