import Link from 'next/link'
import { fetchExam, fetchExamResults } from '../../../../lib/api'
import { Exam, ExamResult } from '../../../../lib/types'

export default async function ExamDetail({
  params
}: {
  params: { id: string }
}) {
  const exam: Exam = await fetchExam(Number(params.id))
  const results: ExamResult[] = await fetchExamResults(Number(params.id))

  return (
    <div className="max-w-7xl mx-auto">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">{exam.exam_name}</h1>
          <p className="text-gray-600">
            Class {exam.class_id} • {new Date(exam.exam_date).toLocaleDateString()}
          </p>
          <p className="text-gray-500">Subject: {exam.subject_name}</p>
        </div>
        <Link 
          href="/exams"
          className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-primary-600 hover:bg-primary-700"
        >
          Back to Exams
        </Link>
      </div>

      <div className="bg-white shadow overflow-hidden sm:rounded-lg mb-8">
        <div className="px-4 py-5 sm:px-6">
          <h3 className="text-lg leading-6 font-medium text-gray-900">Exam Information</h3>
        </div>
        <div className="border-t border-gray-200 px-4 py-5 sm:p-0">
          <dl className="sm:divide-y sm:divide-gray-200">
            <Detail label="Exam Name" value={exam.exam_name} />
            <Detail label="Date" value={new Date(exam.exam_date).toLocaleDateString()} />
            <Detail label="Class" value={`Class ${exam.class_id}`} />
            <Detail label="Subject" value={exam.subject_name} />
            <Detail label="Total Marks" value={exam.total_marks} />
            <Detail label="Passing Marks" value={exam.passing_marks} />
          </dl>
        </div>
      </div>

      <div>
        <h2 className="text-lg font-medium text-gray-900 mb-4">Exam Results</h2>
        <div className="bg-white shadow overflow-hidden sm:rounded-lg">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <Th title="Student" />
                <Th title="Marks Obtained" />
                <Th title="Percentage" />
                <Th title="Grade" />
                <Th title="Status" />
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {results.map((result) => (
                <tr key={result.result_id}>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                    Student ID: {result.student_id}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {result.marks_obtained} / {exam.total_marks}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {((result.marks_obtained / exam.total_marks) * 100).toFixed(2)}%
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                      getGradeColor(result.grade)
                    }`}>
                      {result.grade}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                      result.marks_obtained >= exam.passing_marks ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
                    }`}>
                      {result.marks_obtained >= exam.passing_marks ? 'Pass' : 'Fail'}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}

// Utility components
function Detail({ label, value }: { label: string, value: any }) {
  return (
    <div className="py-4 sm:py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
      <dt className="text-sm font-medium text-gray-500">{label}</dt>
      <dd className="mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2">{value}</dd>
    </div>
  )
}

function Th({ title }: { title: string }) {
  return (
    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
      {title}
    </th>
  )
}

function getGradeColor(grade: string) {
  switch (grade) {
    case 'A': return 'bg-green-100 text-green-800';
    case 'B': return 'bg-blue-100 text-blue-800';
    case 'C': return 'bg-yellow-100 text-yellow-800';
    default: return 'bg-red-100 text-red-800';
  }
}
