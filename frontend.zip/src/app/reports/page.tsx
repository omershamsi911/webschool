"use client";
import { useEffect, useState } from 'react';

export default function ReportsPage() {
  // Placeholder for future real API integration
  const [reports, setReports] = useState([
    { title: 'Student Attendance', description: 'Daily, monthly and yearly attendance reports' },
    { title: 'Fee Collection', description: 'Fee collection and pending fees reports' },
    { title: 'Exam Results', description: 'Class-wise and student-wise exam performance' },
    { title: 'Student Progress', description: 'Academic progress over time' },
    { title: 'Class Performance', description: 'Comparison of class performance' },
    { title: 'Custom Reports', description: 'Generate custom reports based on filters' },
  ]);

  return (
    <div className="max-w-7xl mx-auto">
      <h1 className="text-2xl font-bold text-gray-900 mb-6">Reports</h1>
      <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
        {reports.map((report, index) => (
          <div key={index} className="bg-white shadow-lg hover:shadow-xl transition-shadow sm:rounded-lg">
            <div className="px-4 py-5 sm:p-6">
              <h3 className="text-lg leading-6 font-medium text-gray-900 mb-2">{report.title}</h3>
              <p className="mt-1 text-sm text-gray-500 mb-4">{report.description}</p>
              <div className="mt-4">
                <button className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-primary-600 hover:bg-primary-700 transition-colors">
                  Generate Report
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}